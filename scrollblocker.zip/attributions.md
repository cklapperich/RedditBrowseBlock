blockicon from Mihimimimi on flaticon.com https://www.flaticon.com/free-icon/block_7596460

Reddit icon from iconpacks.net https://www.iconpacks.net/free-icon/reddit-logo-2436.html